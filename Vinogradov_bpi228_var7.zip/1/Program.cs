﻿using System.IO;
using System.Text;
using System.Text.RegularExpressions;
namespace _19._10
{
    internal class Program
    {
        public static bool ReadPath(out string path, string[] _head)
        {
            string[] arr;
            string[] head;
            path = "";

            while (true)
            {
                Console.WriteLine("Введите адрес файла:");
                path = Console.ReadLine();
                Console.WriteLine();
                if (path == "-1")
                    return false;
                try
                {
                    arr = File.ReadAllLines(path);

                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nВведите корректный адрес файла");
                    Console.WriteLine("Для выхода в меню введите -1");
                }
            }

            while (true)
            {
                try
                {
                    head = arr[0].Split(',');
                    if (head.Length != _head.Length)
                        throw new Exception();
                    for (int i = 1; i < arr.Length; ++i)
                    {
                        string line = arr[i];
                        int check = 1;
                        int t = 0;
                        for (int j = 0; j < line.Length; ++j)
                        {
                            if (line[j] == '\"')
                                t = (t + 1) % 2;
                            if (t == 0 && line[j] == ',')
                                check += 1;
                        }
                        if (check != head.Length)
                            throw new Exception();
                    }

                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nВведите адрес файла, структура которого совпадает с файлом computer_games.csv:");
                    Console.WriteLine("Для выхода в меню введите -1");
                    while (true)
                    {
                        Console.WriteLine("Введите адрес файла:");
                        path = Console.ReadLine();
                        Console.WriteLine();
                        if (path == "-1")
                            return false;
                        try
                        {
                            arr = File.ReadAllLines(path);

                            break;
                        }
                        catch (Exception e2)
                        {
                            Console.WriteLine("\nВведите корректный адрес файла");
                            Console.WriteLine("Для выхода в меню введите -1");
                        }
                    }
                }
            }
            Console.WriteLine("Структура файла совпадает с файлом computer_games.csv\n");
            return true;
        }

        public static void PrintAllMaxis(string[] arr)
        {
            string[] head = arr[0].Split(',');
            int ind = 0;
            List<string> ans = new List<string>();
            ans.Add(String.Join(',', head));
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Developer")
                {
                    ind = i;
                    break;
                }
            }

            for (int i = 1; i < arr.Length; ++i)
            {
                string lines = arr[i];
                int t = 0;
                string s = "";
                List<string> line = new List<string> { };
                for (int j = 0; j < lines.Length; ++j)
                {
                    if (lines[j] == '\"')
                    {
                        t = (t + 1) % 2;
                    }
                    if (lines[j] != ',' && lines[j] != '\"')
                        s += lines[j];
                    if (lines[j] == ',' && t == 0)
                    {
                        line.Add(s);
                        s = "";
                    }
                }
                line.Add(s);
                /*foreach (string item in line)
                    Console.Write($"{item} ");
                Console.WriteLine();*/

                if (line[ind] == "Maxis")
                {
                    ans.Add(String.Join(',', line));
                    foreach (string item in line)
                        Console.Write($"{item} ");
                    Console.WriteLine();
                }
            }
            Console.WriteLine();
            File.WriteAllLines("../../../Developer_Maxis.csv", ans);
        }

        public static void MySort(string[] arr)
        {
            string[] head = arr[0].Split(',');

            List<string> ans_win = new List<string> { };
            List<string> ans_win_mac = new List<string> { };
            List<string> ans_other = new List<string> { };

            ans_win.Add(String.Join(',', head));
            ans_win_mac.Add(String.Join(',', head));
            ans_other.Add(String.Join(',', head));

            int ind_os = 0;
            int ind_date = 0;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Operating System")
                {
                    ind_os = i;
                    break;
                }
            }
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Date Released")
                {
                    ind_date = i;
                    break;
                }
            }

            int min_year = 3000;
            int max_year = 0;
            for (int i = 1; i < arr.Length; ++i)
            {
                string lines = arr[i];
                int t = 0;
                string s = "";
                List<string> line = new List<string> { };
                for (int j = 0; j < lines.Length; ++j)
                {
                    if (lines[j] == '\"')
                    {
                        t = (t + 1) % 2;
                    }
                    if (lines[j] != ',' && lines[j] != '\"')
                        s += lines[j];
                    if (lines[j] == ',' && t == 0)
                    {
                        line.Add(s);
                        s = "";
                    }
                }

                line.Add(s);
                int cnt = 0;
                bool check = false;
                for (int j = 0; j < line[^1].Count(); ++j)
                {
                    if (Char.IsNumber(line[^1][j]))
                        cnt++;
                    else
                        cnt = 0;
                    if (cnt == 4)
                    {
                        check = true;
                        string sc = line[^1];
                        line.RemoveAt(line.Count - 1);
                        string year = Convert.ToString(sc[j - 3]) + Convert.ToString(sc[j - 2]);
                        year += Convert.ToString(sc[j - 1]) + Convert.ToString(sc[j]);
                        line.Add(year);
                        break;
                    }
                }
                if (!check)
                    line[^1] = "-";
                if (line[^1] != "-")
                {
                    min_year = Math.Min(min_year, Convert.ToInt32(line[^1]));
                    max_year = Math.Max(max_year, Convert.ToInt32(line[^1]));
                }

                if (line[ind_os] == "Microsoft Windows")
                    ans_win.Add(String.Join(',', line));
                else if (line[ind_os] == "Microsoft Windows macOS" || line[ind_os] == "macOS Microsoft Windows")
                    ans_win_mac.Add(String.Join(',', line));
                else
                    ans_other.Add(String.Join(',', line));
            }

            for (int i = 1; i < ans_win.Count; ++i)
            {
                for (int j = i + 1; j < ans_win.Count; ++j)
                {
                    if (Convert.ToInt32(ans_win[j][ind_date]) < Convert.ToInt32(ans_win[i][ind_date]))
                    {
                        string t = ans_win[j];
                        ans_win[j] = ans_win[i];
                        ans_win[i] = t;
                    }
                }
            }

            for (int i = 1; i < ans_win_mac.Count; ++i)
            {
                for (int j = i + 1; j < ans_win_mac.Count; ++j)
                {
                    if (Convert.ToInt32(ans_win_mac[j][ind_date]) < Convert.ToInt32(ans_win_mac[i][ind_date]))
                    {
                        string t = ans_win_mac[j];
                        ans_win_mac[j] = ans_win_mac[i];
                        ans_win_mac[i] = t;
                    }
                }
            }

            for (int i = 1; i < ans_other.Count; ++i)
            {
                for (int j = i + 1; j < ans_other.Count; ++j)
                {
                    if (Convert.ToInt32(ans_other[j][ind_date]) < Convert.ToInt32(ans_other[i][ind_date]))
                    {
                        string t = ans_other[j];
                        ans_other[j] = ans_other[i];
                        ans_other[i] = t;
                    }
                }
            }

            List<string> ans = new List<string> { };
            Console.WriteLine($"Разница в представлении игр - {max_year - min_year}");
            foreach (string item in ans_win)
            {
                Console.WriteLine(item);
                ans.Add(item);
            }
            foreach (string item in ans_win_mac)
            {
                Console.WriteLine(item);
                ans.Add(item);
            }
            foreach (string item in ans_other)
            {
                Console.WriteLine(item);
                ans.Add(item);
            }
            Console.WriteLine();

            File.WriteAllLines("../../../Microsoft_Windows_Sort.csv", ans_win);
            File.WriteAllLines("../../../Microsoft_Windows_Mac_Sort.csv", ans_win_mac);
        }

        public static void AboveAverage(string[] arr)
        {
            string[] head = arr[0].Split(',');

            int ind_date;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Date Released")
                {
                    ind_date = i;
                    break;
                }
            }

            double average = 0;
            List<string> allLines = new List<string> { };
            List<string> ans = new List<string> { };
            ans.Add(String.Join(',', head));
            for (int i = 1; i < arr.Length; ++i)
            {
                string lines = arr[i];
                int t = 0;
                string s = "";
                List<string> line = new List<string> { };
                for (int j = 0; j < lines.Length; ++j)
                {
                    if (lines[j] == '\"')
                    {
                        t = (t + 1) % 2;
                    }
                    if (lines[j] != ',' && lines[j] != '\"')
                        s += lines[j];
                    if (lines[j] == ',' && t == 0)
                    {
                        line.Add(s);
                        s = "";
                    }
                }

                line.Add(s);
                int cnt = 0;
                bool check = false;
                for (int j = 0; j < line[^1].Count(); ++j)
                {
                    if (Char.IsNumber(line[^1][j]))
                        cnt++;
                    else
                        cnt = 0;
                    if (cnt == 4)
                    {
                        check = true;
                        string sc = line[^1];
                        line.RemoveAt(line.Count - 1);
                        string year = Convert.ToString(sc[j - 3]) + Convert.ToString(sc[j - 2]);
                        year += Convert.ToString(sc[j - 1]) + Convert.ToString(sc[j]);
                        line.Add(year);
                        break;
                    }
                }
                if (!check)
                    line[^1] = "-";
                if (line[^1] != "-")
                    average += Convert.ToInt32(line[^1]);
                allLines.Add(String.Join(',', line));
            }
            average /= (arr.Length - 1);

            foreach (string item in allLines)
            {
                string[] line = item.Split(',');
                if (line[^1] != "-" && Convert.ToInt32(line[^1]) > average)
                    ans.Add(item);
            }

            Console.WriteLine("Введите имя файла, в который хотите сохранить выборку:");
            string file_name = Console.ReadLine();
            foreach (string item in ans)
                Console.WriteLine(item);
            Console.WriteLine();

            File.WriteAllLines($"../../../{file_name}.csv", ans);
        }

        public static void ShowStatistics(string[] arr)
        {
            string[] head = arr[0].Split(',');

            int ind_date = 0;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Date Released")
                {
                    ind_date = i;
                    break;
                }
            }

            int ind_prod = 0;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Producer")
                {
                    ind_prod = i;
                    break;
                }
            }

            int ind_os = 0;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Operating System")
                {
                    ind_os = i;
                    break;
                }
            }

            int ind_g = 0;
            for (int i = 0; i < head.Length; ++i)
            {
                if (head[i] == "Genre")
                {
                    ind_g = i;
                    break;
                }
            }

            List<string> allLines = new List<string> { };
            List<string> ans1 = new List<string> { };
            List<string> ans2 = new List<string> { };
            int ans2_year = 3000;
            List<string> ans3 = new List<string> { };
            List<int> ans3_cnt = new List<int> { };
            List<string> ans4 = new List<string> { };
            int ans4_min = 0;
            ans2.Add(String.Join(',', head));

            for (int i = 1; i < arr.Length; ++i)
            {
                string lines = arr[i];
                int t = 0;
                string s = "";
                List<string> line = new List<string> { };
                for (int j = 0; j < lines.Length; ++j)
                {
                    if (lines[j] == '\"')
                    {
                        t = (t + 1) % 2;
                    }
                    if (lines[j] != ',' && lines[j] != '\"')
                        s += lines[j];
                    if (lines[j] == ',' && t == 0)
                    {
                        line.Add(s);
                        s = "";
                    }
                }

                line.Add(s);
                int cnt = 0;
                bool check = false;
                for (int j = 0; j < line[^1].Count(); ++j)
                {
                    if (Char.IsNumber(line[^1][j]))
                        cnt++;
                    else
                        cnt = 0;
                    if (cnt == 4)
                    {
                        check = true;
                        string sc = line[^1];
                        line.RemoveAt(line.Count - 1);
                        string year = Convert.ToString(sc[j - 3]) + Convert.ToString(sc[j - 2]);
                        year += Convert.ToString(sc[j - 1]) + Convert.ToString(sc[j]);
                        line.Add(year);
                        break;
                    }
                }
                if (!check)
                    line[^1] = "-";
                allLines.Add(String.Join(',', line));
            }

            foreach (string item in allLines)
            {
                string[] line = item.Split(',');

                bool check = false;
                for (int i = 0; i < ans1.Count; ++i)
                    if (ans1[i].Contains(line[ind_prod]))
                    {
                        check = true;
                        string[] a_ans1 = ans1[i].Split(',');
                        int c = Convert.ToInt32(a_ans1[1]) + 1;
                        a_ans1[1] = Convert.ToString(c);
                        ans1[i] = String.Join(',', a_ans1);
                        break;
                    }
                if (!check)
                {
                    ans1.Add($"{line[ind_prod]},1");
                }

                if (line[ind_date] != "-" && line[ind_os] == "Microsoft Windows" && line[ind_g] == "First-person shooter" && ans2_year > Convert.ToInt32(line[ind_date]))
                {
                    ans2_year = Convert.ToInt32(line[ind_date]);
                    ans2.Clear();
                    ans2.Add(String.Join(',', head));
                    ans2.Add(item);
                }
                else if (line[ind_date] != "-" && line[ind_os] == "Microsoft Windows" && line[ind_g] == "First-person shooter" && ans2_year == Convert.ToInt32(line[ind_date]))
                    ans2.Add(item);

                check = false;
                for (int i = 0; i < ans3.Count; ++i)
                    if (ans3[i].Contains(line[ind_g]))
                    {
                        check = true;
                        string[] a_ans3 = ans3[i].Split(',');
                        if (line[ind_date] != "-")
                        {
                            int c = Convert.ToInt32(a_ans3[1]) + Convert.ToInt32(line[ind_date]);
                            a_ans3[1] = Convert.ToString(c);
                            ans3[i] = String.Join(',', a_ans3);
                            if (i < ans3.Count)
                                ans3_cnt[i]++;
                        }
                        break;
                    }
                if (!check)
                {
                    ans3.Add($"{line[ind_g]},{line[ind_date]}");
                    ans3_cnt.Add(1);
                }

                check = false;
                for (int i = 0; i < ans4.Count; ++i)
                    if (ans4[i].Contains(line[ind_prod]))
                    {
                        check = true;
                        string[] a_ans4 = ans4[i].Split(',');
                        int c = Convert.ToInt32(a_ans4[1]) + 1;
                        a_ans4[1] = Convert.ToString(c);
                        ans4[i] = String.Join(',', a_ans4);
                        ans4_min = Math.Min(ans4_min, c);
                        break;
                    }
                if (!check)
                {
                    ans4.Add($"{line[ind_prod]},1");
                    ans4_min = 1;
                }
            }

            for (int i = 0; i < ans4.Count; ++i)
            {
                string[] line4 = ans4[i].Split(',');
                if (line4[^1] != Convert.ToString(ans4_min))
                {
                    ans4.RemoveAt(i);
                    --i;
                }
            }

            for (int i = 0; i < ans3.Count; ++i)
            {
                string[] line3 = ans3[i].Split(',');
                if (line3[1] != "-")
                {
                    double c = Convert.ToDouble(line3[1]) / ans3_cnt[i];
                    line3[1] = Convert.ToString(c);
                    ans3[i] = String.Join(',', line3);
                }
            }
            foreach (string item in ans1)
            {
                string[] line = item.Split(',');
                Console.WriteLine($"{line[0]} - {line[1]}");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            foreach (string item in ans2)
            {
                string[] line = item.Split(',');
                for (int i = 0; i < line.Length; ++i)
                    Console.Write($"{line[i]} ");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine();
            foreach (string item in ans3)
            {
                string[] line = item.Split(',');
                Console.WriteLine($"{line[0]} - {line[1]}");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            foreach (string item in ans4)
            {
                string[] line = item.Split(',');
                for (int i = 0; i < line.Length; ++i)
                    Console.Write($"{line[i]} ");
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        public static void Solution()
        {
            string[] arr;
            string[] head;
            string path = "", pathDefault;
            while (true)
            {
                try
                {
                    Console.WriteLine("Поместите исходный файл 7 варианта в папку, в которой находится решение");
                    pathDefault = @"../../../computer_games.csv";
                    arr = File.ReadAllLines(pathDefault);
                    head = arr[0].Split(',');
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Вы не справились с задачей\n");
                    Console.WriteLine("Проверьте, что исходный файл закрыт и находится в папке рядом с программой\n");
                    Environment.Exit(-1);
                }
            }
            Console.WriteLine("Исходный файл находится там, где надо\n");

            while (true)
            {
                Console.WriteLine("Введите 1, если хотите ввести адрес файла для чтения");
                Console.WriteLine("Введите 2, если хотите вывести на экран информацию о всех компьютерных играх, имеющих свойство Developer = Maxis");
                Console.WriteLine("Введите 3, если хотите вывести на экран переупорядоченный набор исходных данных об играх");
                Console.WriteLine("Введите 4, если хотите вывести на экран выборку игр, год релиза которых больше среднего значения");
                Console.WriteLine("Введите 5, если хотите вывести на экран свободную статистику по данным загруженного файла");
                Console.WriteLine("Введите 0, если хотите завершить программу\n");

                string input = Console.ReadLine();
                Console.WriteLine();
                int choice = -1;
                if (!int.TryParse(input, out choice) || choice < 0 || choice > 5)
                {
                    Console.WriteLine("Введите данные в верном формате\n");
                    continue;
                }
                if (choice == 0)
                    break;
                else if (path == "" && choice != 0 && choice != 1)
                    Console.WriteLine("Введите адрес файла");
                else if (choice == 1)
                {
                    if (ReadPath(out path, head))
                    {
                        arr = File.ReadAllLines(path);
                        head = arr[0].Split(',');
                    }
                }
                else if (choice == 2)
                {
                    PrintAllMaxis(arr);
                }
                else if (choice == 3)
                {
                    MySort(arr);
                }
                else if (choice == 4)
                {
                    AboveAverage(arr);
                }
                else if (choice == 5)
                {
                    ShowStatistics(arr);
                }
            }
            Console.WriteLine("Спасибо за работу с программой");
            Console.WriteLine("Работа программы завершена");
        }

        public static void Main()
        {
            // var 7
            // Виноградов Владимир

            Solution();
        }
    }
}